package com.example.camerabeats;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensormanager = null;
    private Sensor HeartRateSensor;

    private int HeartRate = 0;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice smartwatch;
    private BluetoothSocket bluetoothSocket;

    private TextView heartRateTextView, heart, watch;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensormanager = (SensorManager)getSystemService(SENSOR_SERVICE);
        HeartRateSensor = sensormanager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        HeartRateSensor = sensormanager.getDefaultSensor(Sensor.TYPE_LIGHT);

        heartRateTextView = findViewById(R.id.heartRate);
        heart = (TextView) findViewById(R.id.heart);
        watch = (TextView) findViewById(R.id.smartwatch);


        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            // Device doesn't support Bluetooth
            return;
        }

        // Find the paired smartwatch
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getName().equals("SmartwatchName")) {
                smartwatch = device;
                break;
            }
        }

        // Establishing Bluetooth connection
        try {
            bluetoothSocket = smartwatch.createRfcommSocketToServiceRecord(UUID.fromString("Bluetooth_UUID"));
            bluetoothSocket.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }


        // Start a thread to continuously read heart rate data
        new Thread(new HeartRateReader()).start();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor.getType() == Sensor.TYPE_HEART_RATE);
        HeartRate = (int) sensorEvent.values[0];
        int heart = HeartRate;
        heartRateTextView.setText(String.valueOf(heart));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    private class HeartRateReader implements Runnable {
        @Override
        public void run() {
            try {
                InputStream inputStream = bluetoothSocket.getInputStream();
                while (true) {
                    // Read heart rate data from the input stream
                    // Update UI with heart rate data
                    // Example: heartRateTextView.setText("Heart Rate: " + heartRate);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

